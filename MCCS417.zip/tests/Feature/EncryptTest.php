<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Util\CommonHelper;
use App\Util\GenerateCode;

class EncryptTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function testExample()
    {
        /* $str = '11';
        $token = CommonHelper::encryptCommon($str);
        echo '加密:'.$token;
        echo '解密：'.CommonHelper::decryptCommon($token);
        echo '     ';
        $str = '11';
        $token = CommonHelper::encryptCommon($str);
        echo '加密:'.$token;
        echo '解密：'.CommonHelper::decryptCommon($token); */
        //$str = 'test';
        //$token = CommonHelper::encryptCommon($str,"mccs");
       // echo '加密:'.$token;
       // echo '解密：'.CommonHelper::decryptCommon($token,"mccs");
        echo "  ".GenerateCode::getStringRandom(4)."   ";
        echo "  ".GenerateCode::getStringRandom(4)."   ";
       echo "  ".GenerateCode::randomString(4)."   ";
       echo "  ".GenerateCode::randomString(4)."   ";
    } 
}
