<?php
namespace App\Util;

use Illuminate\Support\Str;

class CommonHelper
{
    public static function encrypt($string,$operation,$key=''){
        $key=md5($key);
        $key_length=strlen($key);
        $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;
        $string_length=strlen($string);
        $rndkey=$box=array();
        $result='';
        for($i=0;$i<=255;$i++){
            $rndkey[$i]=ord($key[$i%$key_length]);
            $box[$i]=$i;
        }
        for($j=$i=0;$i<256;$i++){
            $j=($j+$box[$i]+$rndkey[$i])%256;
            $tmp=$box[$i];
            $box[$i]=$box[$j];
            $box[$j]=$tmp;
        }
        for($a=$j=$i=0;$i<$string_length;$i++){
            $a=($a+1)%256;
            $j=($j+$box[$a])%256;
            $tmp=$box[$a];
            $box[$a]=$box[$j];
            $box[$j]=$tmp;
            $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
        }
        if($operation=='D'){
            if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8)){
                return substr($result,8);
            }else{
                return'';
            }
        }else{
            return str_replace('=','',base64_encode($result));
        }
    }
    
    public static function encryptCommon($str,$key=''){
        if($key == '' || $key == null){
            $key = env("APP_KEY","mccs");
            if (Str::startsWith($key, 'base64:')) {
                $key = base64_decode(substr($key, 7));
            }
        }
        if (Str::startsWith($key, 'base64:')) {
            $key = base64_decode(substr($key, 7));
        }
        $encryotStr = CommonHelper::encrypt($str, 'E', $key);
        return str_replace('=','',base64_encode($encryotStr));
    }
    
    public static function decryptCommon($content,$key=''){
        if($key == '' || $key == null){
            $key = env("APP_KEY","mccs");
            if (Str::startsWith($key, 'base64:')) {
                $key = base64_decode(substr($key, 7));
            }
        }
        
        if (Str::startsWith($key, 'base64:')) { 
            $key = base64_decode(substr($key, 7));
        }
        return CommonHelper::encrypt(base64_decode($content), 'D', $key);
    }
}

