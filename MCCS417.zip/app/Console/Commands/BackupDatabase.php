<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class BackupDatabase extends Command
{
    protected $signature = 'db:backup';

    protected $description = 'Backup the database';

    protected $process;

    public function __construct()
    {
        parent::__construct();

        $this->process = new Process(sprintf(
            'mysqldump -u%s -p%s %s > %s',
            config('database.connections.mysql.username'),
            config('database.connections.mysql.password'),
            config('database.connections.mysql.database'),
            storage_path('backup/backup_'.date("Y-m-d",time()).'.sql')
        ));
    }

    public function handle()
    {
        try {
            $this->process->mustRun();
            Log::channel('key')->info("db backup success");
            $arr = Storage::disk('backups')->allFiles();
            $today =strtotime(date("Y-m-d ", time()));
            foreach ($arr as $v){
                $str = substr($v, 7,10);
                if($today - strtotime($str) > 604800 && Storage::disk('backups')->exists($v)){
                    Storage::disk('backups')->delete($v);
                }
            }
        } catch (ProcessFailedException $exception) {
            Log::channel('key')->info("db backup fail ".$exception->getMessage());
        }
    }
}
