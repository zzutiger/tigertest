<?php
namespace App\Model;

use App\Model\Base\BaseModel;

class Contact  extends BaseModel
{
    protected $table = 'contacts';
    protected $fillable = ['name', 'email', 'phone', 'status'];
    public $timestamps = FALSE;
}
