<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use App\Util\RSA;
class RegisterUserPost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $rsa = new RSA();
        if (Cache::has($this->get('pk'))) {
            $key = "-----BEGIN PRIVATE KEY-----\n" . wordwrap(Cache::pull($this->get('pk')), 64, "\n", true) . "\n-----END PRIVATE KEY-----";
            $rsa->init($key, $this->get('pk'),true);
        }
        $this['password'] = $rsa->priv_decode($this->get('password'));
        $this['password_confirmation'] = $rsa->priv_decode($this->get('password_confirmation'));
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        
        return [
            'name' => ['required', 'unique:users',
                function ($attribute, $value, $fail) {
                    $result = preg_match('/^([A-Za-z0-9@_.]*){1,64}$/', $value);
                    if ($result != 1) {
                        $fail(__("validation.invalidCharter"));
                        return;
                    }
                }
            ],
            'password' => ['required', 'confirmed',
                function ($attribute, $value, $fail) {
                    $result = preg_match('/^(?=.*[a-zA-Z\\d])(?=.*[a-zA-Z!#$%()*+,-.\/\<\=\>?@[\\]^_`{|}~])(?=.*[\\d!#$%()*+,-.\/\<\=\>?@[\\]^_`{|}~]).{8,32}$/', $value);
                    if ($result != 1) {
                        $fail(__("passwords.password_requirements"));
                        return;
                    }
                }]
           ];
    }
}
