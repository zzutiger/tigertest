<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\App;
use Closure;

class LangSet
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $lang = substr($request->header("Accept-Language","zh-CN"),0,3);
        if($lang != "zh-"){
            App::setLocale("en");
        }else{
            App::setLocale("zh-CN");
        }
        return $next($request);
    }
}
