<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContactsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contacts', function (Blueprint $table) {
            $table->integerIncrements('id');
            $table->string("name")->comment("技术人员名称");
            $table->string('email')->comment("邮箱");
            $table->string('phone')->comment("手机号");
            $table->tinyInteger('status')->default(0)->comment("0:在职;1:不在职");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contacts');
    }
}
