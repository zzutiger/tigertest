<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStaticHtmlsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('static_htmls', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string("name")->unique()->comment("项目名称");
            $table->bigInteger('user_id')->default(0)->index();
            $table->string('link')->unique()->comment("唯一链接");
            $table->string('origin_name')->nullable()->comment("上传文件的原始名称");
            $table->tinyInteger('status')->default(0)->comment("1:删除，0:未删除");
            $table->string('real_path')->nullable()->comment("解压路径");
            $table->string("zip_path")->nullable()->comment("上传的压缩文件");
            $table->integer("upload_times")->default(0)->comment("上传文件次数");
            $table->unsignedInteger('created_at');
            $table->unsignedInteger('updated_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('static_htmls');
    }
}
