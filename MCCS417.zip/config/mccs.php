<?php
use App\Util\CommonHelper;
return [
   
    "sign_key" => "718e1e45c4952bc218491b87cc1a4ded",
    "file_max_size" =>150,
    "web_index" => "index.html",
    "welcome" => [
        "funcs" => [
            [
                "name" => "APP分发服务",
                "img" => "image/app_distribute.png",
                "route_name" => 'index',
                "desc" => "建设中",
                "online" => 0,
            ],
            [
                "name" => "行为分析服务",
                "img" => 'image/user_analysis.png',
                "route_name" => 'index',
                "desc" => "建设中",
                "online" => 0,
            ],
            [
                "name" => "WEB静态部署服务",
                "img" => "image/web_static.png",
                "route_name" => 'web',
                "desc" => "",
                "online" => 1,
            ],
            [
                "name" => "热更新服务",
                "img" => "image/hot_update.png",
                "route_name" => 'index',
                "desc" => "建设中",
                "online" => 0,
            ]
        ],
        "func_online" => [
            "name" => "分发平台上线",
            "desc" => "为开发者提供更多快捷，简单的应用分发平台，帮助开发者以最轻松，高效的方式将应用分发给渠道海外用户",
            "more" => "了解更多"
        ],
        "pops" => [
            [
                "name" => "DMSS",
                "img" => "image/icon_dmss.png",
                "route_name" => 'index',
                "desc" =>""
            ],
            [
                "name" => "DSS Mobile",
                "img" => "image/icon_dssmobile.png",
                "route_name" => 'index',
                "desc" =>""
            ],
            
            [
                "name" => "智慧警务",
                "img" => "image/icon_police.png",
                "route_name" => 'index',
                "desc" =>""
            ],
            [
                "name" => "云睿",
                "img" => "image/icon_yunrui.png",
                "route_name" => 'index',
                "desc" =>""
            ]
        ],
        
        "pubs_title" => "开发流程",
        "pubs" => [
            [
                "name" => "注册认证",
                "img" => "image/process01.png"
            ],
            [
                "name" => "创建项目",
                "img" => "image/process02.png"
            ],
            [
                "name" => "开发测试",
                "img" => "image/process03.png"
            ],
            [
                "name" => "提交发布",
                "img" => "image/process04.png"
            ]
            
        ],
        "contacts_txt" => [
            'title' => "技术支持",
            'name_label'=>"技术人员：",
            'email_label' =>"邮箱：",
            'phone_label' => '手机号：'
        ],
        "contacts" =>[
            [
                "name" => "陆利刚",
                "email" => CommonHelper::decryptCommon('bWxXK0w3eVVoakFpNE9jTTVnQWY1TkVtNFNJb25LS3Z0RE43WHhxS01n','mccs'),
                "phone" => "18969963087"
            ],
            [
                "name" => "刘晓虎",
                "email" => CommonHelper::decryptCommon('d0ZlNWVPZVQwRFFpL00wLzl3NGY1ZDRUeFNjaGdiYTZwVFZ3R1ZlR01Jcw','mccs'),
                "phone" => "18106513408"
            ]
        ],
        "company" =>[
            "name" => "大华股份",
            "icp" => "浙ICP07004180",
            "beian" => "33010802003424",
            "beian_address" => "浙公网安备 33010802003424号"
        ]
    ]
];