<?php
return [
    
/*=========================add by luligang==========================*/
    'delete_confirm' => '确认删除吗?',
    'appDrop' => 'App下线',
    'userAddTitle' => '添加新用户',
    'userAddConfirm' => '密码确认',
    'userAddPassword' => '密码',
    'userAddEmail' => '邮箱',
    'userAddName' => '用户名',
    'userAddModify' => '修改用户信息',
    'userAddOperation' => '操作',
    'userAddType' => '账户类型',
    'userAddSuccess' => '添加成功!',
    'userUpdateSuccess' => '更新成功!',
    'userDeleteSuccess' => '用户已删除!',
];
