<?php
return [
    
/*=========================add by luligang==========================*/
    'Close' => 'Close',
    'Save' => 'Save',
    'Add' => 'Add',
    'Delete' => 'Delete',
    'Edit' => 'Edit',
    'Login' => 'Login',
    'Logout' => 'Logout',
    'ResetPwd' => '密码重置',
    'verCode' => '验证码',
    'nameorpassword_error' => '用户名或密码错误',
    'Cancel' => 'Cancel'
];