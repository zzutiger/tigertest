<?php
return [
    
/*=========================add by liuxiaohu==========================*/
    'code' => [
        'c_10000' => '10000',
        'c_10001' => '10001',
        'c_10002' => '10002',
        'c_10003' => '10003',
        'c_10004' => '10004',
        'c_10005' => '10005',
        'c_40000' => '40000',
        'c_40003' => '40003',
        'c_40004' => '40004',
        'c_50000' => '50000',
    ],
    'msg' => [
        'm_10000' => ":success",
        'm_10001' => ":fail",
        'm_10002' => "参数未签名",
        'm_10003' => "缺少参数",
        'm_10004' => "参数失效",
        'm_10005' => "参数不合法",
        'm_40000' => "Bad Request",
        'm_40003' => "Permission denied",
        'm_40004' => "Request Not Found",
        'm_50000' => "Service exception",
    ],
    
    "400" =>[
        "code" => "40000",
        'msg' => "Bad Request"
    ],
    "401" =>[
        "code" => "40001",
        'msg' => "Session failed, please login again"
    ],
    "403" =>[
        "code" => "40003",
        'msg' => "Permission denied"
    ],
    "404" =>[
        "code" => "40004",
        'msg' => "Request Not Found"
    ],
    "419" =>[
        "code" => "40019",
        'msg' => "Authentication timeout"
    ],
    "429" =>[
        "code" => "40029",
        'msg' => "Too many requests"
    ],
    "500" =>[
        "code" => "50000",
        'msg' => "Service exception"
    ],
    "501" =>[
        "code" => "50001",
        'msg' => "未实现"
    ],
    "502" =>[
        "code" => "50002",
        'msg' => "Bad Gateway"
    ],
    "503" =>[
        "code" => "50003",
        'msg' => "The service is unavailable"
    ],
    "504" =>[
        "code" => "50004",
        'msg' => "Gateway timeout"
    ]
];
