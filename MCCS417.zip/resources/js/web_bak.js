var isCheckAll = false;
var ids = new Array();
var lang = (navigator.userLanguage||navigator.language||navigator.browserLanguage).toLowerCase();
function swapCheck() {
	if (isCheckAll) {
		$("input[name='p']").each(function() {
			this.checked = false;
		});
		isCheckAll = false;
		ids.length = 0;
		$("#ids").val('');
	} else {
		ids.length = 0;
		$("input[name='p']").each(function() {
			this.checked = true;
			ids.push(this.value);
		});
		$("#ids").val(ids.join(','));
		isCheckAll = true;
	}
	changeDeleteSrc();
	
}

function changeDeleteSrc(){
	if(ids.length > 0){
		$('#delete-more-icon').attr("src",  "image/delete_n.png");
		$("#delete-more-txt").removeClass("no-check");
	}else{
		$('#delete-more-icon').attr("src",  "image/delete_d.png");
		$("#delete-more-txt").addClass("no-check");
	}
}

function checkChange(obj){
	if(obj.checked){
		var c = true;
		$("input[name='p']").each(function() {
			if(!this.checked){
				c = false;
			}
		});
		
		if(c){
			isCheckAll = true;
			$("#check-all").prop("checked", true);
		}else{
			isCheckAll = false;
			$("#check-all").prop("checked", false);
		}
    }else{
    	isCheckAll = false;
    	$("#check-all").prop("checked", false);
    }

	ids.length = 0;
	$("input[name='p']").each(function() {
		if(this.checked){
			ids.push(this.value);
		}
	});
	changeDeleteSrc();
	$("#ids").val(ids.join(','));
}

function changeMode(showId,hideId,inputId){
	$("#"+showId).removeClass("mccs-hide");
	$("#"+hideId).addClass("mccs-hide");
	$("#"+inputId).val($("#"+showId).text()); 
}

var optMore = false;
var formId = null;
function showDialog(more,id,nameId){
	formId = id;
	optMore= more;
	var title = '';
	if(more){
		if(ids.length == 0){
			return;
		}else{
			title = '';
			for(j = 0; j < ids.length; j++) {
				title +=$('#normal-'+ids[j]).text();
				if(j != ids.length-1){
					title+="，";
				}
			} 
		}
    }else{
    	title = $('#'+nameId).text();
    }
	$("#dialog").removeClass("mccs-hide");
	if(title != null){
		$('#dialgTitle').text(delete_items+title);
	} 
}

function hideDialog(){
	$("#dialog").addClass("mccs-hide");
}

function showMsg(content, success){
	var tip = document.getElementById("msg-tip");
	tip.innerText=content;
	$("#msg-container").removeClass("mccs-hide");
	
	if(success){
		$("#msg-container").addClass("msg-success")
	}else{
		$("#msg-container").removeClass("msg-success")
	}
	setTimeout(hideMsg,2000);
}

function hideMsg(){
	$("#msg-container").addClass("mccs-hide");
}

function hideLoading(){
	$("#loading").addClass("mccs-hide");
}

function showLoading(){
	$("#loading").removeClass("mccs-hide");
}

 $(function(){
	$("#cancel").unbind('click').click(function(){
		hideDialog();
	});
	$("#ok").unbind('click').click(function(){
		hideDialog();
		var form = document.getElementById(formId);
		deleteData(form);
	});
    var x = 24;
    var y = -150;
    hideLoading();
    $("a.qr_code").unbind('click').click(function(e) {
    	$("#qr_code").remove();
    	var txt = this.href;
    	var tooltip = "<div id='qr_code' class='qr_code_big' >" +
    	        "<span class='singleline qr_code_title'>"+this.title+"</span>"+
    	        "<div id='qr_code_img'></div>" +
    			"<a href='' download='' id='qr_code_a'>"+web_qr_export+"</a></div>";
        $("body").append(tooltip);
       /* $(".qr_code_big").css({
        	'top':(e.pageY + y) + "px",
        	'left':(e.pageX + x) +"px"
        });*/
        jQuery('#qr_code_img').qrcode({
            render: "canvas",
            width: 200,
            height: 200,
            text: txt
        });
        var data = $("canvas")[0].toDataURL().replace("image/png", "image/octet-stream;"); 　
    	var filename = this.title+"_"+txt.substring(txt.lastIndexOf("/")+1)+".png";
    	$("#qr_code_a").attr("href",data); 
    	$("#qr_code_a").attr("download",filename);
    	document.addEventListener('click',function (e1) {
    		var parent=$(e1.target).parents('.qr_code');
    		if(parent.length == 0){
    			$("#qr_code").remove();
    		}
       });
    });
});
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

function submitData(form, funcSucc,funcErr){
	try{
		var formData = signFormData(form,false);
	    $.ajax({
	      headers: {
	          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	          
	      },
	      type: form.method,
	      url: form.action,
	      data: formData,
	      processData:false,
	      contentType: false,
	      success:funcSucc,
	      error:funcErr
	    }); 
	}catch(err){
		hideLoading();
		if (lang == "zh-cn") {
			showMsg("请升级浏览器",false);
		}else{
			showMsg("Please upgrade your browser",false);
		}
	}
}
function deleteData(form){
    showLoading();
    submitData(form,function(data){
    	if(data != null && data.success){
      	    window.location.reload();
        }else if(data != null){
	      	 hideLoading();
	       	 showMsg(data.msg,false);
	       	 expireSession(data);
        }
   },function(err){
	   	 hideLoading();
	   	 showMsg(web_internal_error,false);
	});
}
function createWeb(formId){
	var form = document.getElementById(formId);
    showLoading();
    submitData(form,function(data){
    	 if(data != null && data.success){
       	     window.location.href = data.data.url;
         }else if(data != null){
       	     hideLoading();
        	 showMsg(data.msg,false);
        	 expireSession(data);
         }
    },function(err){
    	 hideLoading();
    	 showMsg(web_internal_error,false);
 	});
}

function expireSession(data){
	if(data && !data.success){
		if(data.code == '40001' || data.code == '40019'){
			setTimeout(function () {  window.location.reload(); }, 1000);
		}
	}
}

function fileSelect(itemId, elementId){
	  var file = document.getElementById(elementId);
      if(file.value != ""){
    	  showLoading();
    	  var fileName = file.value.substring(file.value.lastIndexOf(".")+1).toLowerCase();
          if(fileName !="zip"){
        	  file.value="";
        	  hideLoading();
              showMsg(zip_limit,false);
              return
          }
          if(file.files[0].size > file_max_size * 1024 * 1024){
        	  hideLoading();
        	  file.value="";
              showMsg(file_size_limit,false);
        	  return;
          }
          
          filemd5sum(file,itemId);
     }
}

function filemd5sum(file,itemId) {
	try{
		var form = document.getElementById("file-upload-"+itemId);
	    var fileData = file.files[0];
	    var tmp_md5;
	    var blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice,
	        chunkSize = 8097152,
	        chunks = Math.ceil(fileData.size / chunkSize),
	        currentChunk = 0,
	        spark = new SparkMD5.ArrayBuffer(),
	        fileReader = new FileReader();

	    fileReader.onload = function(e) {
	        spark.append(e.target.result); 
	        currentChunk++;
	        if (currentChunk < chunks) {
	            loadNext();
	        } else {
	            tmp_md5 = spark.end();
	            $("#file-content-"+itemId).attr("value",tmp_md5); 
	            submitData(form,function(data){
	          	    file.value="";
	          	  $("#file-content-"+itemId).attr("value",""); 
	                if(data != null && data.success){
	               	   window.location.reload();
	                }else if(data != null){
	               	   hideLoading();
	               	   showMsg(data.msg,false);
	               	   expireSession(data);
	                }
	            },function(err){
	          	  hideLoading();
	           	  file.value="";
	           	  $("#file-content-"+itemId).attr("value",""); 
	           	  showMsg(web_internal_error,false);
	         	});
	        }
	    };

	    fileReader.onerror = function() {
	    	 hideLoading();
	    	 showMsg(web_parse_fail,false);
	    };

	    function loadNext() {
	        var start = currentChunk * chunkSize,
	            end = ((start + chunkSize) >= fileData.size) ? fileData.size : start + chunkSize;
	        fileReader.readAsArrayBuffer(blobSlice.call(fileData, start, end));
	    }
	    loadNext();
	}catch(err){
		hideLoading();
		showMsg(web_parse_fail,false);
	}
}

function logout(formId){
	var form = document.getElementById(formId);
	submitData(form,function(data){
		if(data != null && data.success){
      	  if(data.data != null && data.data.url != null && data.data.url.startsWith('http')){
      		  window.location.href= encodeURI(data.data.url);
      	  }else{
      		  window.location.reload();
      	  }
        }else if(data != null){
      	  expireSession(data);
        }
	},function(err){
		window.location.reload();
	});
}

function changeNameUp(itemId, elementId){
	event.preventDefault();
	if(event.keyCode == "13"){
		var form = document.getElementById("form-name-"+itemId);
		if(form.style.display == "none"){
			return;
		}
		changeName(itemId, elementId);
	}
}
function changeNameDown(itemId){
	if(event.keyCode == "13" || event.keyCode == "32"){
		event.preventDefault();
	}
}
function changeName(itemId, elementId){
	var form = document.getElementById("form-name-"+itemId);
	var qrName = document.getElementById("qr-"+itemId);
	var normalElement = document.getElementById(elementId);
	var name = form['name'].value;
	if(name == null || name.trim() == ""){
		showMsg(name_not_null,false);
		return;
	}
	if(name.length < 1 || name.lenght > 64){
		showMsg(name_limit_length,false);
		return;
	}
	if(normalElement.innerText == name){
		$("#form-name-"+itemId).addClass("mccs-hide");
        $('#'+elementId).removeClass("mccs-hide");
		showMsg(name_save_success,true);
        return;
	}
	var regex = new RegExp("^([\\u4E00-\\uFA29]|[\\uE7C7-\\uE7F3]|[a-zA-Z0-9]){1,64}$");
	var res = regex.test(name);
	if(!res){
	   showMsg(name_limit,false);
	   return;
	}
	showLoading();
	submitData(form,function(data){
		hideLoading();
        if(data != null && data.success){
            showMsg(data.msg,true);
            if(data.data != null){
          	  normalElement.innerText= name;
          	  qrName .title = name;
          	  normalElement.title = name;
            }
            $("#form-name-"+itemId).addClass("mccs-hide");
            $('#'+elementId).removeClass("mccs-hide");
        }else if(data != null){
       	 showMsg(data.msg,false);
       	 expireSession(data);
        }
	},function(err){
		hideLoading();
  	    showMsg(web_internal_error,false);
	});
}

function signFormData(form, trim){
	var formData = new FormData(form);
	var timestamp = new Date().getTime();
	formData.append("timestamp", timestamp);
	var arr = [];
	for (var key of formData.keys()) {
        if( arr.indexOf(key) == -1 && key != 'file'){
        	arr.push(key);
        }
    }
    arr.sort();
    var str='';
    for(var i in arr){
    	var a = formData.getAll(arr[i]);
    	var key = arr[i];
    	if(arr[i].endsWith('[]')){
    		key = key.substring(0,key.length -2);
    		for(var j in a){
    			if(trim){
            		var v = a[j].trim();
                    if(v.length != 0){
                    	str +=key+"["+j+"]"+"="+v+"&"
                    }
            	}else{
            		str +=key+"["+j+"]"+"="+a[j]+"&"
            	}
    			
            }
        }else if(a.length > 1){
        	if(trim){
        		var v = a[a.length-1].trim();
                if(v.length != 0){
                	str +=key+"="+v+"&"
                }
        	}else{
        		str +=key+"="+a[a.length-1]+"&"
        	}
        	
        }else if(a.length == 1){
        	if(trim){
        		var v = a[0].trim();
                if(v.length != 0){
                	str +=key+"="+v+"&"
                }
        	}else{
        		var v = a[0];
                str +=key+"="+v+"&"
        	}
        }
    	
    }
    var key = formData.get("_token");
    str +=key;
    var sign = md5(str);
    formData.append("sign",sign);
    return formData;
}

