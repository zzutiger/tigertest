window.addEventListener('DOMContentLoaded', function() {
	document.onkeydown = function (e) {
        var theEvent = window.event || e;
        var code = theEvent.keyCode || theEvent.which;
        if (code == 13) {
            if ($('#password').val().trim() == '' || $('#name').val().trim() == '') return;
            $("#loginBtn").click();
        }
    };
	
	function sendData(){
		$('#loginForm').submit();
	}
	$('#loginBtn').click(function(){
		$.ajax ({
			url: 'getPK',
	        type: "GET",
	        dataType:'json',
	        async:false,
	        success:function(data)
	        {
	        	var encrypt = new JSEncrypt();
	    		encrypt.setPublicKey(atob(data.pk));
	    		var password = encrypt.encrypt($('#password').val());
	    		$('#password').val(password);
	    		var timestamp = Date.parse(new Date());
	    		$('#timestamp').val(timestamp);
	    		$('#pk').val(data.pk);
	    		var form = document.getElementById('loginForm');
	    		$('#sign').val(signData(form,timestamp));
	    		sendData();
	        },
	        //处理完成
	        complete: function(){
	        },
	        //报错
	        error: function(data){
	        	
	        }
		});
		return;
	});
	$('#name').on('input propertychange', function(){
		if($(this).val().trim() != '' && $('#password').val().trim() != ''){
			$('#loginBtn').removeAttr('disabled');
		}else {
			$('#loginBtn').attr('disabled',true);
		}
		if($(this).val().length > 64){
			$(this).val( $(this).val().substring(0,64) );
        }
	});

	$('#password').on('input propertychange', function(){
		if($(this).val().trim() != '' && $('#name').val().trim() != ''){
			$('#loginBtn').removeAttr('disabled');
		}else {
			$('#loginBtn').attr('disabled',true);
		}
		if($(this).val().length > 32){
			$(this).val( $(this).val().substring(0,32) );
        }
	});
});