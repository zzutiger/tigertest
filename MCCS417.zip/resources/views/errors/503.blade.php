<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{{ config('app.name', 'MCCS') }}</title>
    <link href="{{ asset('css/err.css') }}" rel="stylesheet">
</head>
<body>
    <div class="content">
       { <img  src="{{asset('image/error_common.png')}}">
        <span class="error-msg">{{ isset($code) ? $code : "503" }} | {{ isset($msg) ? $msg : __('err.503.msg') }}</span>
    </div>
</body>
</html>