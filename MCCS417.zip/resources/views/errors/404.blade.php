<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{{ config('app.name', 'MCCS') }}</title>
    <link rel="shortcut icon" href="{{ asset('image/favicon.png') }}">
    <link href="{{ asset('css/err.css') }}" rel="stylesheet">
</head>
<body>
    <div class="content">
        <img  src="{{asset('image/404pic.png')}}">
        <img  src="{{asset('image/404.png')}}" class="statusCode">
        {{$exception ?? '' ? $exception ?? ''->getMessage() : __('webs.web_404')}}
    </div>
</body>
</html>