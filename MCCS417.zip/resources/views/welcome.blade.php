<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>{{ config('app.name', 'MCCS') }}</title>
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}">
    <link href="{{ asset('css/mccs.css') }}" rel="stylesheet">
    <script src="{{ asset('js/jquery-3.4.1.min.js') }}"></script>
    <script src="{{ asset('js/banner.js') }}"></script>
    <script src="{{ asset('js/md5.min.js')}}"></script>
    <script src="{{ asset('js/web.js') }}"></script>
</head>
<body>
<div class="top-bg"></div>
@include('top')
<div class="banner">
    <div class="b-img">
      	<a href="#" style="background:url({{asset('image/banner01.png')}}) center no-repeat;"></a>
      	<a href="#" style="background:url({{asset('image/banner02.png')}}) center no-repeat;"></a>
    </div>
    <div class="b-list"></div>
</div>
<div class="func">
    @foreach(config('mccs.welcome.funcs') as $func)
        <div class="funcItem">
    		<div class="funcCenter">
    			<a href="{{route($func['route_name'])}}"  onclick="{{$func['route_name'] == 'index' ? 'event.preventDefault();' :''}}">
    				<img src="{{asset($func['img'])}}" class="imgLogo" />
    				<span class="funcTxt {{$func['online'] == 0 ? 'funcTxtOff' : ''}}">
    				     {{ $func['name'] }}
    			    </span>
    			    <span class="funcDesc">{{ $func['desc'] }}</span>
    			</a>
    		</div>
    	</div>
     @endforeach
</div>
<div style="text-align: center;clear: left;margin-top: 84px">
	<div style="font-size:2.5em">
		{{config('mccs.welcome.func_online.name')}}
	</div>
	<div style="margin: 15px auto;font-size: 1em">
		{{config('mccs.welcome.func_online.desc')}}
	</div>
	<div style="margin: 26px auto">
		<a href="#" class="more" onclick="event.preventDefault();">
		  {{config('mccs.welcome.func_online.more')}}
	   </a>
	</div>
</div>
<div class="pop">
    @foreach(config('mccs.welcome.pops') as $pop)
        <div class="popItem">
    		<div class="funcCenter">
    			<a href="{{route($pop['route_name'])}}" onclick="{{$pop['route_name'] == 'index' ? 'event.preventDefault();' :''}}">
    				<img src="{{asset($pop['img'])}}" class="popImg" />
    				<span class="popTxt">
    				     {{ $pop['name'] }}
    			    </span>
    			    <span class="popDesc">
    			    	{{ $pop['desc'] }}
    			    </span>
    			</a>
    		</div>
        </div>
     @endforeach
    <div class="popLine"></div>
</div>
<div class="mccs-clear"></div>
<div class="pub">
	<div class="pubTitle">{{config('mccs.welcome.pubs_title')}}</div>
	<div class="pubC">
	    @foreach(config('mccs.welcome.pubs') as $pub)
            <div class="pubItem">
    			<img src="{{asset($pub['img'])}}" class="pubImg" />
				<div class="pubTxt">
				    {{ $pub['name'] }}
			    </div>
    		</div>
       @endforeach
	</div>
</div>
<div  class="footer">
	<div class="p-m-c">
		 <div>{{config('mccs.welcome.contacts_txt.title')}}</div>
		 @if(empty($contacts))
		    @foreach(config('mccs.welcome.contacts') as $contact)
    		   <div class="contactItem">
        			<div><span>{{config('mccs.welcome.contacts_txt.name_label')}}</span><span>{{$contact['name']}}</span></div>
        			<div style="margin-top: 12px;margin-bottom: 12px"><span>{{config('mccs.welcome.contacts_txt.email_label')}}</span><span>{{$contact['email']}}</span></div>
        			<div><span>{{config('mccs.welcome.contacts_txt.phone_label')}}</span><span>{{$contact['phone']}}</span></div>
    		   </div>
		    @endforeach
		  @else
		     @foreach($contacts as $contact)
    		   <div class="contactItem">
        			<div><span>{{config('mccs.welcome.contacts_txt.name_label')}}</span><span>{{$contact['name']}}</span></div>
        			<div style="margin-top: 12px;margin-bottom: 12px"><span>{{config('mccs.welcome.contacts_txt.email_label')}}</span><span>{{$contact['email']}}</span></div>
        			<div><span>{{config('mccs.welcome.contacts_txt.phone_label')}}</span><span>{{$contact['phone']}}</span></div>
    		   </div>
		     @endforeach
		  @endif
		 
	</div>

	<div class="beian">
            &copy;{{date('Y').config('mccs.welcome.company.name')}}<a href="http://www.beian.miit.gov.cn/" 
            target="_blank">&nbsp;&nbsp;{{config('mccs.welcome.company.icp')}}</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode={{config('mccs.welcome.company.beian')}}" id="safety" target="_blank">{{config('mccs.welcome.company.beian_address')}}</a>
	</div>
</div>
</body>
</html>
